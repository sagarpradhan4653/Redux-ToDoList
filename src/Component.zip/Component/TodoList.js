import React, { Fragment } from 'react'
import { MDBInput, MDBIcon, MDBBtn } from "mdbreact";
import { connect } from 'react-redux'




class TodoList extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            name: '',
            date: '',
            discr: '',
            checked: true,
            edit: -1,
            suggest: '',
            sendSuggest: ""

        }
    }

    // componentDidMount() {
    //     if (this.props.stateLove) {
    //         this.props.history.push('/UserVerification')

    //     } else {
    //         this.props.history.push('/TodoList')
    //     }
    // }

    ItemSuggest = (e) => {
        this.setState({
            sendSuggest: e.target.value
        })
    }

    SearchTodo = () => {
        this.setState({ suggest: this.state.sendSuggest })
    }

    AddInArry = (e) => {
        e.preventDefault()


        if (this.state.edit == -1) {
            this.props.userInfo(this.state)
        }
        else {
            this.props.editValue({ ind: this.state.edit, obj: this.state })
            this.setState({ edit: -1 })
        }
        this.clearInputItem()


        // this.props.todoDate(this.state.date)

    }


    DeleteHandle = (ind) => {
        this.props.todoDelete({ index: ind })

    }

    // AddDate = () => {
    //     this.props.todoDate(this.state.date)

    // }

    changeValue = (name, value) => {
        this.setState({ [name]: value })
    }

    //for empty the value of input box
    clearInputItem = () => {
        this.setState({
            name: "",
            date: '',
            discr: ""
        })
    }


    // for sending the value into input box
    HandleUpdate = (ind) => {
        var findItem = this.props.state.userDetails[ind]
        this.setState(
            {
                name: findItem.name,
                date: findItem.date,
                discr: findItem.discr
            }
        )
        this.setState({ edit: ind })
    }


    // checkUpdate = (index) => {
    //     this.setState({

    //     })
    // }

    checkUpdate = () => {


        this.setState({ checked: !this.state.checked })
        this.props.checkUpdate({ inda: this.state.edit, newChecked: this.state.checked })

    }










    render() {
        console.log(this.state.checked, 'checkbox toggling');
        const curDate = new Date().toLocaleDateString('en-GB')
        console.log(curDate, "PC date");
        console.log(this.state.date, "calender date");

        return (
            <div>
                {/* {curDate < this.state.date && 'you are successfull in this'} */}
                <h1>TodoList</h1><br />
                {this.props.state.userVerify.map((item, index) => {
                    return <h3 key={index}>{item.email}</h3>
                })}
                <MDBInput
                    label="What do you wants to do?"
                    outline icon="user"
                    type="text"
                    value={this.state.name}
                    name="name"
                    onChange={e => { this.changeValue(e.target.name, e.target.value) }}
                    placeholder="What's your plan ">

                </MDBInput>
                <MDBInput
                    type="date"
                    outline icon="Dates"
                    value={this.state.date}
                    name="date"
                    onChange={e => { this.changeValue(e.target.name, e.target.value) }} >

                </MDBInput>
                <MDBInput
                    name="discr"
                    onChange={e => { this.changeValue(e.target.name, e.target.value) }}
                    type="text"
                    value={this.state.discr}
                    label="Add Discription"
                    rows="4"
                    icon="pencil-alt"
                />
                <input className="btn btn-outline-success" type="button" onClick={this.AddInArry} value="ADD"></input><br />
                {/* <Fragment>
                    <MDBBtn tag="a" type="button" onClick={this.AddInArry} value={this.state.edit == -1 ? "EDIT" : "UPDATE"} floating gradient="peach">
                        <MDBIcon icon="address-card" />
                    </MDBBtn>
                </Fragment> */}
                <h2> Search Task</h2>
                <MDBInput
                    onChange={this.ItemSuggest}
                    label="Finding Recent Task"
                    outline icon="search"
                    type="text"
                    name="task"
                    placeholder="Search The Task"
                />

                <Fragment>
                    <MDBBtn tag="a" type="button" onClick={this.SearchTodo} floating gradient="peach">
                        <MDBIcon icon="search" />
                    </MDBBtn>
                </Fragment>
                <ul>
                    {this.props.state.userDetails.filter(item => item.name.includes(this.state.suggest)).map((item, index) => {
                        console.log(item, "hello")
                        return <li key={index}>
                            <h3 className={item.checked ? "checkbox" : ""}> {item.name}</h3>
                            <p className={item.checked ? "checkbox" : ""}>{item.date}</p>
                            <p className={item.checked ? "checkbox" : ""}>{item.discr}</p>
                            {console.log(item.checked, "checked")}
                            <p><strong>{curDate > new Date(item.date).toLocaleDateString('en-GB') ? 'Due Date is Passed' : ''} </strong></p>
                            {/* <span className={item.checked ? "checkbox" : ""}></span> */}
                            <input type="checkbox" onClick={this.checkUpdate} />
                            <input className="btn btn-dark" type="button" value={this.state.edit == -1 ? "EDIT" : "UPDATE"} onClick={(e) => { this.state.edit == -1 ? this.HandleUpdate(index) : this.AddInArry(e) }} />
                            <input className="btn btn-warning" onClick={() => { this.DeleteHandle(index) }} type="button" value="Delete" />

                        </li>
                    })}
                </ul>


            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        state
        // stateLove:state.userVerify != null ? true : false
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        userInfo: (val) => dispatch({ type: 'TODO_ITEM', payload: val }),
        todoDelete: (valu) => dispatch({ type: 'TODO_DELETE', payload: valu }),
        editValue: (value) => dispatch({ type: 'EDIT_VALUE', payload: value }),
        checkUpdate: (v) => dispatch({ type: 'CHECK_BOX', payload: v })



    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TodoList)
