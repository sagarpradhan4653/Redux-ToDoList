import React from 'react'

export default function reducer(state = {}, action) {
    switch (action.type) {

        // case 'TODO_DATE': {
        //     return { ...state, userDetails: [...state.userDetails,action.payload] }
        // }

        case 'TODO_ITEM': {
            return { ...state, userDetails: [...state.userDetails, action.payload] }

        }

        case 'USER_VERIFY': {
            return { ...state, userVerify: [...state.userVerify, action.payload] }
        }

        case 'TODO_DELETE': {
            // return{
            //     ...state, userDetails:state.userDetails.filter((user,i)=>i !=action.payload)

            const { index } = action.payload
            return { ...state, userDetails: [...state.userDetails.slice(0, index), ...state.userDetails.slice(index + 1)] }
        }
        case 'DONE_LOGOUT': {
            return { ...state, userVerify: [], userDetails: [] }
        }

        case 'EDIT_VALUE': {
            const { ind, obj } = action.payload
            return { ...state, userDetails: [...state.userDetails.slice(0, ind), obj, ...state.userDetails.slice(ind + 1)] }
        }

        case 'CHECK_BOX': {
            const {newChecked,inda} = action.payload
            return {
                ...state, userDetails:[...state.userDetails.slice(0, inda), newChecked, ...state.userDetails.slice(inda + 1) ]
            }
        }



        default: {
            return state
        }
    }
}



