import React  from 'react'
import { useForm } from 'react-hook-form'
import { connect } from 'react-redux'
import './UserVerification.css';

function UserVerification(props) {
    const { register, handleSubmit, errors } = useForm()


    const onSubmit = data => {
        props.verify(data)
        // for redirect the page to todolist
        if (!props.sendToTodolist) {
            props.history.push('/TodoList')
        }
        console.log(data);


    }


    // console.log(props.state);

   

    return (
        <>
            <div className="text-white rgba-stylish-strong py-3 px-3 z-depth-4">
                <form id="formV" className="card bg-dark text-white" onSubmit={handleSubmit(onSubmit)} >

                    <div className="form-group">
                        <div className='text-center'>
                            <div className='white-text mb-5 mt-4 font-weight-bold'>
                                <label for="exampleInputEmail1">Email address</label>
                                <input name="email" type="email" className="form-control" placeholder="Enter email"
                                    ref={register({ required: { value: true, message: 'Email is Needed' }, pattern: { value: /^[\w-\.]+@([\w-]+\.)+[\w-]+$/, message: 'Email Format Wrong' } })} />
                            </div>
                            {errors.email && <span>{errors.email.message}</span>}

                        </div>
                    </div>
                    <div className="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input name="password" type="password" className="form-control" placeholder="Password" ref={register({ required: { value: true, message: 'Password is required' } })} />
                    </div>
                    {errors.password && <span>{errors.password.message}</span>}
                    <a href='#!' className='green-text ml-1 font-weight-bold'></a>
                    <input type="submit" />
                </form>
            </div>

        </>
    )
}


const mapStateToProps = (state) => {
    return {

        state,
        sendToTodolist: state.userVerify.password != null ? true : false

    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        verify: (val) => dispatch({ type: 'USER_VERIFY', payload: val })
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(UserVerification)
