import { MDBBtn, MDBInput, MDBIcon } from 'mdbreact'
import React, { Fragment } from 'react'
import { connect } from 'react-redux'

export class SearchTask extends React.Component {
    constructor(props) {
        super(props)
    }




    render() {
        return (
            <div>
                Search Item
                <MDBBtn>All Task</MDBBtn>
                <MDBBtn>Pending Task</MDBBtn>
                <MDBBtn>Completed Task</MDBBtn>

                <ol>
                    {this.props.state.userDetails.map((item, index) => {
                        console.log(item, "hello")
                        return <li key={index}>
                            <h3> {item.name}</h3>
                            <p>{item.date}</p>
                            <p>{item.discr}</p>
                        </li>
                    })}
                </ol>
               
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        state
    }
}

export default connect(mapStateToProps)(SearchTask)
